#!/usr/bin/env python3
"""Embed verified Classic Warcraft III artwork into the standalone HTML before APK compilation.
Each candidate must return actual PNG bytes. Missing files are never silently replaced by unrelated art.
No previous user preferences, cups or comparisons are bundled.
"""
import base64, concurrent.futures, json, re, time, urllib.parse, urllib.request
from pathlib import Path
from collections import defaultdict
root=Path(__file__).resolve().parent
html=root/'app/src/main/assets/index.html'
s=html.read_text()
roster=json.loads(re.search(r'<script id="roster" type="application/json">(.*?)</script>',s,re.S).group(1))
icons={}
for entity in roster:
    if entity.get('icon'):icons[entity['icon'].lower()]=entity['icon']
    for ability in entity.get('abilities',[]):
        if ability.get('icon'):icons[ability['icon'].lower()]=ability['icon']
print('Source Classic icon keys:',len(icons),flush=True)
headers={'User-Agent':'Mozilla/5.0 (compatible; WC3Journal personal offline reference; source: warcraft.wiki.gg)'}
def read(candidate):
    url='https://warcraft.wiki.gg/wiki/Special:Redirect/file/'+urllib.parse.quote(candidate+'.png')
    for src in [url,'https://liquipedia.net/commons/Special:Redirect/file/'+urllib.parse.quote('Wc3'+candidate+'.png')]:
        try:
            with urllib.request.urlopen(urllib.request.Request(src,headers=headers),timeout=18) as res:
                raw=res.read(150000)
                if raw.startswith(b'\x89PNG\r\n\x1a\n') and 1000<=len(raw)<150000:
                    return candidate,raw,src
        except Exception:
            continue
    return candidate,None,None
mapping={};notfound=[];from_site=defaultdict(int)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    for name,data,source in pool.map(read,icons.values()):
        if data:
            mapping[name.lower()]='data:image/png;base64,'+base64.b64encode(data).decode('ascii')
            from_site['wiki.gg' if 'wiki.gg' in source else 'liquipedia']+=1
        else:notfound.append(name)
print('Downloaded verified PNGs:',len(mapping),'of',len(icons),'by source',dict(from_site),flush=True)
print('Unavailable:',', '.join(notfound),flush=True)
hero_keys={e['icon'].lower() for e in roster if e['kind']=='hero' and e.get('icon')}
print('Hero portraits:',len(hero_keys.intersection(mapping)),'/',len(hero_keys),flush=True)
# Protect against shipping another installer with almost no portraits. A few rare game icons may be absent.
if len(hero_keys.intersection(mapping))<20 or len(mapping)<round(len(icons)*0.6):
    raise RuntimeError('Too many classic icons could not be fetched. Do not ship incomplete artwork.')
seed='<script id="bundledIcons" type="application/json">{}</script>'
assert seed in s, 'Icon manifest slot missing'
s=s.replace(seed,'<script id="bundledIcons" type="application/json">'+json.dumps(mapping,separators=(',',':'))+'</script>',1)
html.write_text(s)
print('Embedded offline HTML',html.stat().st_size,'bytes',flush=True)

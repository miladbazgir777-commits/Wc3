# WC3 Journal — native Android project

A private, offline-first WebView application. Its assets/index.html is a clean edition of the Warcraft III Preference Codex (V9 functionality), with **no imported comparisons, cups, Faction Wars, snapshots, or personal preferences**. The 72-entry roster and game mechanics are built-in reference data, not saved user results.

## Build the installable APK

Requirements: Android Studio with Android SDK Platform 35, Android SDK Build Tools, JDK 17 and Internet access to download Gradle/Android Gradle Plugin dependencies. This environment did not have the Android SDK or a compatible APK toolchain, so **no compiled APK is included and a device installation has not been tested**.

1. In Android Studio choose **Open** and select the `WC3Journal_AndroidStudio` directory.
2. If prompted, generate a standard Gradle wrapper for version 8.7, or select an installed Gradle 8.7 distribution. (A Gradle-wrapper JAR cannot be bundled in this offline environment.)
3. Let Gradle sync and install missing SDK 35 components if Android Studio prompts.
4. Select **Build → Build APK(s)**. The debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfer the APK to your Android phone and install it, allowing installation from your file manager when Android asks.

Alternatively, the included `.github/workflows/build-android.yml` can build the debug APK using GitHub Actions without installing Android Studio. Upload the project **contents (not its parent folder)** to the root of a GitHub repository, run **Actions → Build Android APK → Run workflow**, then download the `WC3-Journal-APK` workflow artifact (unzip it to obtain the installable `.apk`). This requires a GitHub account and network access.

`app/src/main/assets/index.html` can be updated independently with another compatible journal HTML as long as its native bridge functions are preserved.

## Android data location and import/export

- Main state: Android's private internal storage, `getFilesDir()/journal-state.json`, typically `/data/user/0/com.des.wc3journal/files/journal-state.json` (actual path is OS-controlled and is not normally available to file managers).
- Automatic snapshots: `getFilesDir()/journal-snapshots.json`.
- Secondary localStorage data also exists inside Android System WebView's app sandbox. Main state is read from the private JSON file first.
- No storage permission required. Import uses Android's document picker; Export JSON and Export HTML use `ACTION_CREATE_DOCUMENT` and allow you to choose a user-visible file location.
- **Import JSON** accepts earlier Codex V6–V9 schema-1 backups for comparisons and cup brackets. Faction Wars are supported when present; old versions will not understand new war data.
- **Import old HTML** extracts only the `stateSeed` and optional `assetSeed` JSON from V6–V9 portable standalone HTML exports, without executing code from the imported file. If a previous HTML only stored progress in its browser localStorage and does not embed data, open that older app and export JSON instead.
- All imports are explicit and opt-in; the shipped app contains none of the user's earlier progress.
- Reinstalling after uninstall or tapping Android **Clear storage** destroys this private data. Android OS cloud backup is explicitly disabled to ensure a fresh install is empty; export JSON regularly.
- Imported image bulk selection uses Android's document picker. `webkitdirectory` folder-selection may not be supported by the installed Android System WebView; select multiple icons instead.

## Security / scope

The JS bridge is exposed only to a locally bundled asset. External navigation is opened in the system browser, not in this bridge-enabled WebView. `android:allowBackup=false`; HTTPS-only network resources, with optional online icon fetching disabled by default. No trackers or remote data sync.

Launcher icon uses the exact image supplied for this project, resized into five screen-density variants.


## V10 artwork and study references
- Four user-supplied faction paintings are embedded in HTML for offline display and portable HTML export. The home screen selects one of four two-tone race themes.
- `download_icons.py` downloads exact Classic PNG filenames from Warcraft Wiki (then Liquipedia Commons) and embeds verified images into the HTML before the Android build. This ensures offline portraits and ability icons, subject to availability at build time. It refuses to build if too many portraits are missing. The script never uses unrelated placeholder artwork.
- Tap hero, unit or ability icons to open related Liquipedia Warcraft pages in the system browser. Articles may reflect post-1.26 balance changes.
- Cup merging buttons and shortcut preference buttons are removed; JSON and prior HTML import/export remains.
- Starting state is empty (no prior cups, wars or comparisons). Existing installed-app data is stored privately and is not deliberately cleared by updating the APK. Export JSON before uninstalling or clearing data.

## V11 fixes (September 19, 2026)
- Restored full-brightness Warcraft portraits and ability icons: the study-link arrow no longer paints an opaque full-icon overlay.
- Before opening any linked portrait/ability on Liquipedia, a cancellable confirmation dialog names the selected entry. The external URL remains restricted to HTTPS Liquipedia Warcraft pages.
- Cleaned the Home page: four selectable faction emblems remain; the explanatory subtitle, Enter the Journal button and storage footnote have been removed.
- Removed the redundant **More** navigation button/drawer. Swipe the bottom navigation bar horizontally to reach all sections; the selected tab is scrolled into view. Desktop sidebar navigation is unchanged.
- The preview HTML is byte-identical to `app/src/main/assets/index.html`. No previous user preference results are seeded or cleared.

## V12 faction glass artwork
- Hero/unit comparison, ranking, library, bracket, winner, podium, archive and result-timeline cards now show their faction's original painted emblem as a subtle full-card glass watermark and carry its primary faction color. Individual cards no longer show an extra miniature faction badge; faction standings and the explicit results-table emblem column retain their informational emblems.
- Neutral Tavern hero cards use monochrome black-and-white translucent glass with no watermark or miniature faction icon.
- Each painting is referenced from one CSS property at runtime instead of duplicating massive data URIs into card HTML. Portrait/ability icons remain fully bright and show a small outbound-arrow marker.
- All V11 home/navigation removals and the per-link confirmation dialog are retained; no changes to existing ratings, backups, save keys or tournament logic.

## V13 streamlined interface / hero-cup start (September 19, 2026)
- Removed the repeated header Export JSON, Import JSON and portable HTML buttons, and the global Answers/Coverage/Connections/Maturity/Favorite strip. The same export and import features remain accessible in Recovery; standalone HTML export remains in Artwork.
- Removed the redundant Compare-page Heroes-first switch, its coverage status and the pairing-reason eyebrow. Heroes-first remains configurable in Settings; the comparison number remains visible.
- Suppressed the nonessential bottom-corner confirmation toasts, including the native successful-export toast. Serious save/export errors retain warnings. Liquipedia portraits still require an explicit confirmation before opening.
- Made the four faction-painted backgrounds and emblem watermarks moderately stronger without applying filters to any hero or ability portraits; Neutral Tavern remains silver/charcoal glass with no emblem.
- Corrected event delegation so the body’s page attribute cannot intercept clicks on saved-cup archive actions or other controls. The Heroes Cup is not auto-displayed before an explicit creation/selection when the remembered cup has zero completed matches. Existing zero-match cups are preserved in the archive; tap Open bracket to resume them. Cups with actual results continue to open automatically. Units Cup behavior is unchanged.
- The app does not reset locally stored answers, saved tournaments, or the Android native-storage format on update. Export a JSON backup before uninstalling or clearing storage.

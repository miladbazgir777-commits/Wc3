package com.des.wc3journal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

/**
 * Offline, private WebView shell for the original WC3 Journal HTML app.
 * Nothing is seeded from any user's old data. First launch has an empty roster history.
 * Saves happen atomically in getFilesDir()/journal-state.json, not shared storage.
 * The Android document picker is used for JSON/HTML exports and prior HTML backup imports.
 */
public final class MainActivity extends Activity {
    private static final int FILE_INPUT_REQUEST = 6121;
    private static final int EXPORT_REQUEST = 6122;
    private static final String LOCAL_URL = "file:///android_asset/index.html";
    private WebView browser;
    private ValueCallback<Uri[]> fileCallback;
    private volatile File pendingExport;
    private String pendingExportMime;

    @Override public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().setStatusBarColor(0xff090d15);
        getWindow().setNavigationBarColor(0xff090d15);
        browser = new WebView(this);
        browser.setBackgroundColor(0xff090c12);
        setContentView(browser);
        WebSettings s = browser.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setDefaultTextEncodingName("UTF-8");
        browser.addJavascriptInterface(new JournalBridge(), "AndroidJournal");
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (LOCAL_URL.equals(uri.toString())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ex) { toast("No browser is available."); }
                }
                return true;
            }
        });
        browser.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView web, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent open = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                open.addCategory(Intent.CATEGORY_OPENABLE);
                open.setType("*/*");
                String[] types = params.getAcceptTypes();
                if (types != null && types.length != 0) {
                    boolean json = false, image = false;
                    for (String type : types) {
                        if (type.contains("json") || type.contains(".json")) json = true;
                        if (type.contains("image") || type.contains("png") || type.contains("webp")) image = true;
                    }
                    // Keep * / * for JSON: some Android document providers mark .json as text/plain.
                    if (image && !json) open.setType("image/*");
                }
                open.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(open, FILE_INPUT_REQUEST); return true; }
                catch (ActivityNotFoundException ex) { fileCallback = null; toast("No document picker is available."); callback.onReceiveValue(null); return false; }
            }
        });
        browser.loadUrl(LOCAL_URL);
    }

    private void toast(String text) { runOnUiThread(() -> Toast.makeText(this, text, Toast.LENGTH_LONG).show()); }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FILE_INPUT_REQUEST) {
            if (fileCallback == null) return;
            Uri[] selected = null;
            if (result == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    selected = new Uri[count];
                    for (int i = 0; i < count; i++) selected[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) selected = new Uri[] { data.getData() };
            }
            fileCallback.onReceiveValue(selected);
            fileCallback = null;
            return;
        }
        if (request == EXPORT_REQUEST) {
            File file = pendingExport;
            pendingExport = null;
            if (result == RESULT_OK && data != null && data.getData() != null && file != null) {
                try (InputStream input = new FileInputStream(file);
                     OutputStream output = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (output == null) throw new IOException("Cannot open the selected document.");
                    byte[] buffer = new byte[32768]; int n;
                    while ((n = input.read(buffer)) >= 0) output.write(buffer, 0, n);
                    output.flush();
                    // No transient toast for successful exports; keep failure warnings.
                } catch (IOException ex) { toast("Export failed: " + ex.getMessage()); }
            }
            if (file != null) file.delete();
        }
    }

    @Override public void onBackPressed() {
        browser.evaluateJavascript("(function(){if(typeof activePage !== 'undefined' && activePage !== 'home'){go('home');return true;}return false;})()", result -> {
            if (!"true".equals(result)) runOnUiThread(() -> new AlertDialog.Builder(this)
                .setTitle("Close WC3 Journal?")
                .setMessage("Your latest changes are saved on this device.")
                .setNegativeButton("Stay", (d, w) -> {})
                .setPositiveButton("Close", (d, w) -> finish())
                .show());
        });
    }

    @Override protected void onDestroy() {
        if (browser != null) { browser.removeJavascriptInterface("AndroidJournal"); browser.destroy(); browser = null; }
        super.onDestroy();
    }

    public final class JournalBridge {
        private final File data = new File(getFilesDir(), "journal-state.json");
        private final File snapshots = new File(getFilesDir(), "journal-snapshots.json");

        @JavascriptInterface public String readState() { return read(data); }
        @JavascriptInterface public String readSnapshots() { return read(snapshots); }
        @JavascriptInterface public boolean writeState(String text) { return write(data, text); }
        @JavascriptInterface public boolean writeSnapshots(String text) { return write(snapshots, text); }
        @JavascriptInterface public void openStudyUrl(String address) {
            try {
                Uri uri=Uri.parse(address);
                if (!"https".equals(uri.getScheme()) || !"liquipedia.net".equals(uri.getHost())) return;
                runOnUiThread(() -> {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (ActivityNotFoundException ex) { toast("No web browser is available."); }
                });
            } catch (RuntimeException ignored) { toast("Invalid study link."); }
        }
        @JavascriptInterface public String dataLocation() { return "Private app storage / files / journal-state.json"; }

        private String read(File file) {
            try { if (file.exists()) return new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8); }
            catch (IOException error) { toast("Could not read saved data. Use your JSON backup."); }
            return "";
        }
        private synchronized boolean write(File file, String text) {
            File temp = new File(file.getParentFile(), file.getName() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write(text.getBytes(StandardCharsets.UTF_8));
                out.flush(); out.getFD().sync();
            } catch (IOException error) { toast("Save failed. Export a JSON backup."); return false; }
            try { Files.move(temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING); return true; }
            catch (IOException error) { toast("Private data-file update failed."); return false; }
        }

        @JavascriptInterface public void saveFile(String suggestedFilename, String mimeType, String text) {
            if (text == null) return;
            if (pendingExport != null) { toast("Finish the current export first."); return; }
            try {
                File tmp = File.createTempFile("wc3-journal-export-", ".tmp", getCacheDir());
                try (FileOutputStream out = new FileOutputStream(tmp)) {
                    out.write(text.getBytes(StandardCharsets.UTF_8));
                }
                pendingExport = tmp;
                String filename = suggestedFilename.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_");
                if (filename.length() > 128) filename = filename.substring(0, 128);
                if (filename.length() == 0) filename = "WC3_Journal_Backup.json";
                final String safeName = filename;
                final String mime = mimeType != null && mimeType.startsWith("text/html") ? "text/html" :
                    mimeType != null && mimeType.contains("tab-separated") ? "text/tab-separated-values" : "application/json";
                runOnUiThread(() -> {
                    Intent document = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    document.addCategory(Intent.CATEGORY_OPENABLE);
                    document.setType(mime);
                    document.putExtra(Intent.EXTRA_TITLE, safeName);
                    try { startActivityForResult(document, EXPORT_REQUEST); }
                    catch (ActivityNotFoundException ex) { pendingExport.delete(); pendingExport = null; toast("No document picker available for export."); }
                });
            } catch (IOException ex) { toast("Could not prepare export: " + ex.getMessage()); }
        }
    }
}
